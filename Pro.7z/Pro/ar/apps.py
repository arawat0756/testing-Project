from django.apps import AppConfig


class ArConfig(AppConfig):
    name = 'ar'
